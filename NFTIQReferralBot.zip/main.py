import os
import telebot
from replit import db
from flask import Flask, request
import threading

API_TOKEN = os.environ.get("API_TOKEN")
bot = telebot.TeleBot(API_TOKEN)
app = Flask(__name__)

@bot.message_handler(commands=['start'])
def handle_start(message):
    user_id = str(message.from_user.id)
    args = message.text.split()

    if len(args) > 1:
        referrer_id = args[1]
        if user_id != referrer_id:
            if user_id not in db:
                db[user_id] = {'referrer': referrer_id}
                try:
                    bot.send_message(int(referrer_id), f"🎉 You got a referral from @{message.from_user.username or message.from_user.first_name}")
                except:
                    pass
                bot.send_message(message.chat.id, "✅ Welcome to NFTIQ! Your referral has been recorded.")
            else:
                bot.send_message(message.chat.id, "⚠️ You've already started the bot.")
        else:
            bot.send_message(message.chat.id, "⚠️ You can't refer yourself.")
    else:
        bot.send_message(message.chat.id, "👋 Welcome to NFTIQ Bot! Use /referral to get your personal referral link.")

@bot.message_handler(commands=['referral'])
def handle_referral(message):
    user_id = str(message.from_user.id)
    link = f"https://t.me/{bot.get_me().username}?start={user_id}"
    bot.send_message(message.chat.id, f"🔗 Your referral link:\n{link}")

@bot.message_handler(commands=['check'])
def handle_check(message):
    user_id = str(message.from_user.id)
    count = sum(1 for v in db.values() if isinstance(v, dict) and v.get('referrer') == user_id)
    bot.send_message(message.chat.id, f"👥 You've referred {count} user(s).")

@bot.message_handler(commands=['leaderboard'])
def handle_leaderboard(message):
    referral_counts = {}
    for user_id, data in db.items():
        if isinstance(data, dict) and 'referrer' in data:
            referrer_id = data['referrer']
            referral_counts[referrer_id] = referral_counts.get(referrer_id, 0) + 1

    if not referral_counts:
        bot.send_message(message.chat.id, "No referrals recorded yet.")
        return

    sorted_referrals = sorted(referral_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    leaderboard_text = "🏆 *NFTIQ Referral Leaderboard:*\n\n"

    for i, (user_id, count) in enumerate(sorted_referrals, start=1):
        try:
            user = bot.get_chat(user_id)
            name = user.username or user.first_name or f"ID {user_id}"
        except:
            name = f"ID {user_id}"
        leaderboard_text += f"{i}. {name} – {count} referrals\n"

    bot.send_message(message.chat.id, leaderboard_text, parse_mode="Markdown")

@app.route('/', methods=['GET', 'POST'])
def webhook():
    if request.method == 'POST':
        update = telebot.types.Update.de_json(request.stream.read().decode("utf-8"))
        bot.process_new_updates([update])
        return '', 200
    else:
        return "Bot is running."

def run():
    app.run(host="0.0.0.0", port=8080)

threading.Thread(target=run).start()
bot.infinity_polling()